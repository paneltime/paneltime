Paneltime
=========

This package integrates paneldata estimation with a very efficient GARCH e
estimator. 

-------
A longer description will come here