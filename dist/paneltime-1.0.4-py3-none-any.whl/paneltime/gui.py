#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import scrolledtext
import threading
import multi_core
from multiprocessing import pool
import sys


class ScrollText:
	def __init__(self,window,font,state,height=None):
		self.frame = tk.Frame(window)
		xscrollbar = tk.Scrollbar(self.frame,orient='horizontal')
		xscrollbar.pack(side = tk.BOTTOM, fill = tk.X)
		yscrollbar = tk.Scrollbar(self.frame)
		yscrollbar.pack(side = tk.RIGHT, fill = tk.Y)	
		if height is None:
			self.text = tk.Text(self.frame, wrap = tk.NONE,state=state,
				        xscrollcommand = xscrollbar.set,yscrollcommand = yscrollbar.set)
		else:
			self.text = tk.Text(self.frame, wrap = tk.NONE,state=state,
				        xscrollcommand = xscrollbar.set,yscrollcommand = yscrollbar.set,height=height)			
		
		xscrollbar.config(command = self.text.xview)
		yscrollbar.config(command = self.text.yview)
		self.text.pack(fill='both', expand=True)
		self.frame.pack(fill='both', expand=True)
		
	def pack(self,side,fill=None):
		self.frame.pack(side=side,fill=fill)
		
	def get(self,index1,index2):
		return self.text.get(index1,index2)
		
	def delete(self,index1,index2):
		self.text.delete(index1,index2)
		
	def insert(self,index1,chars):
		self.text.insert(index1,chars)		
		
	def see(self,index):
		self.text.see(index)



class window:
	def __init__(self,title,iconpath=None,height=400,width=1000):
		self.win= tk.Tk()
		self.win.title(title)
		self.win.geometry('%sx%s' %(width,height))
		if not iconpath=='':
			self.win.iconbitmap(iconpath)


		bop = tk.Frame()
		bop.pack(side=tk.BOTTOM,fill=tk.BOTH)
		tk.Button(bop, text='Print to stdout', command=self.print).pack(side=tk.LEFT,fill=tk.X)
		tk.Button(bop, text='End with current coefficients', command=self.finalize).pack(side=tk.LEFT)  
		tk.Button(bop, text='Display normality and AC statistics', command=self.norm_and_AC).pack(side=tk.LEFT)   
		tk.Button(bop, text='Copy to clipboard', command=self.copy).pack(side=tk.RIGHT)

		bop = tk.Frame()
		bop.pack(side=tk.TOP,fill=tk.BOTH)		
		self.box = ScrollText(bop, font=("Courier",10, "bold"), state='normal')
		self.box.pack(side=tk.TOP)
		self.output = ScrollText(bop, font=("Courier",10, "bold"), state='normal')		
		self.output.pack(side=tk.TOP)		
		sys.stdout=stdout_redir(self.output)
	

		

				
		
	def print(self):
		sys.stdout=sys.__stdout__
		print(self.box.get(1.0,tk.END))
		sys.stdout=stdout_redir(self.output)
		
	def norm_and_AC(self):
		if self.showNAC==True:
			self.showNAC=False
		else:
			self.showNAC=True
			
	def copy(self):
		self.win.clipboard_clear()
		self.win.clipboard_append(self.box.get(1.0,tk.END))
	
		
	def finalize(self):
		self.finalized=True

	def update(self,string):
		self.box.delete(1.0,tk.END)
		self.box.insert(tk.INSERT,string)
		#self.win.update()
		
	def close(self,x):
		self.win.quit()
		
	def run(self,func,args,close_when_finished=False):
		self.finalized=False
		self.showNAC=False
		p = pool.ThreadPool(processes=1)
		if close_when_finished:
			self.pool=p.apply_async(func, args,callback=self.close)
		else:
			self.pool=p.apply_async(func, args)
		self.win.mainloop() 
		try:
			self.win.destroy()
		except:
			pass
		
	def get(self):
		return self.pool.get()
	
	def save(self):
		print('todo')
		
		
		
		
class stdout_redir(object):
	def __init__(self,textbox):
		self.textbox = textbox

	def write(self,string):
		self.textbox.insert('end', string)
		self.textbox.see('end')
		
def threadit(func,args):
	t = pool.ThreadPool(processes=1, initializer=func, initargs=args)
	a=t.apply_async(func, args)
	return a

a=0

"""import tkinter as tk
import time
import threading
from multiprocessing import pool



def main():
    top = tk.Tk()
    tex = tk.Text(master=top)
    tex.pack(side=tk.TOP)

    a=threadit(tex,dosomething,(tex,))
    top.mainloop()  
    a.get()

def cbc(string, tex):
    return lambda : callback(string, tex)


def callback(string, tex):
    tex.insert(tk.END, string)
    tex.see(tk.END)             # Scroll if necessary
    
    
def threadit(tex,func,args):
    t = pool.ThreadPool(processes=1, initializer=func, initargs=args)
    a=t.apply_async(func, args)
    return a
    
def dosomething(tex):
    for i in range(2):
        time.sleep(5)
        tex.insert(tk.END, "id: %s" %(i,))
    return 1,2



main()"""